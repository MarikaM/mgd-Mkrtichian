<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package mgd-base
 */
?>

<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php get_template_directory_uri() ?>/css/normalize.css">	
        <link rel="stylesheet" href="<?php get_template_directory_uri() ?>/css/helpers.css">
        <link rel="stylesheet" href="<?php get_template_directory_uri() ?>/css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
  </head>

  <body <?php body_class('ui layout '  . $bodyClasses ); ?>>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <div class="canvas">
      <div class="shim">
        <header class="masthead" role="banner">
          <div class="brand">
            <a class="mark" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php bloginfo( 'name' ); ?>"><?php bloginfo( 'name' ); ?></a>
          </div> <!-- /.brand -->
          <nav class="navigation menus" role="navigation">
            <strong class="visuallyhidden">Main Navigation</strong>
            <?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
          </nav>

          <nav class="utility menus">
            <?php wp_nav_menu( array( 'theme_location' => 'utility' ) ); ?>

            <?php get_search_form(); ?>

          </nav><!-- /.utility menus -->

          <nav class="social menus">
            <?php wp_nav_menu( array( 'theme_location' => 'social' ) ); ?>
          </nav>
        </header><!-- /.masthead -->

        <main class="page ui" role="main">
