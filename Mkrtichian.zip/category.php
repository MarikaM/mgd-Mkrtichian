<?php
/**
 * Category Template
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package mgd-base
 */

$queryCat = get_query_var('cat');
$cat = get_category($queryCat);
$slug = $cat->slug;

get_header(); ?>

<div class="main">
  <h1 class="page heading">
    <?php the_archive_title(); ?>
  </h1>

  <div class="items <?php echo $slug ?> ui">
    <?php
    while ( have_posts() ):
      the_post();
      get_template_part( 'content', $slug . '-item' );
    endwhile;

    mgd_base_paging_nav();
    ?>
  </div>
</div><!-- /.main -->

<?php get_footer(); ?>
