<?php
// Get and format Event Dates;
// TODO: move eventDate to functions.php
if ( get_field( 'event_start_date' ) ):
  $eventDate = '<p class="date">' . get_field( 'event_start_date' );
  if ( get_field( 'event_end_date' ) ):
    $eventDate .= ' – ' . get_field( 'event_end_date' );
  endif;
  $eventDate .= '</p>';
endif;
?>

<div <?php post_class( 'home lede ui' ); ?> id="post-<?php the_ID(); ?>">
  <div class="lede attach ui">
    <a href="#" class="permalink">
<?php
if ( has_post_thumbnail() ):
  the_post_thumbnail();
endif;
  ?>
    </a>
  </div> <!-- /.attach -->
  <div class="lede content">
    <div class="lede header">
      <h2 class="lede heading">
        <a href="<?php echo esc_url( get_permalink() ) ?>" class="lede permalink">
        <?php the_title() ?>
        </a>
      </h2> <!-- /.heading -->
      <div class="lede meta">
        <?php echo ent2ncr( $eventDate ); ?>
        <p class="location">
        <?php if ( get_field( 'location' ) ): ?>
          <?php the_field( 'location' ) ?>
        <?php endif; ?>
        </p>
      </div> <!-- /.meta -->
    </div><!-- /.header -->
    <div class="lede copy">
      <?php the_excerpt(); ?>
    </div><!-- /.copy -->
    <div class="lede footer">
      <nav class="lede categories ui">
        <a href="#" class="category">Lecture</a>
        <a href="#" class="category">On Campus</a>
      </nav>
      <nav class="lede tags ui">
        <a href="#" class="tag">Typography</a>
      </nav>
    </div> <!-- /.footer -->
  </div><!-- /.content -->
</div><!-- /.lede -->
