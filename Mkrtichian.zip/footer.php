<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package mgd-base
 */
?>

        </main><!-- /.page -->
      </div><!-- /.shim -->

      <footer class="footer" role="contentinfo">
        <nav class="departments menus ui">
          <?php wp_nav_menu( array( 'theme_location' => 'departments' ) ); ?>
        </nav>
        <p class="legal">&copy; Maryland Institute College of Art</p>
      </footer>

    </div><!-- /.canvas -->

  <?php wp_footer(); ?>
 <script src="<?php get_template_directory_uri() ?>/js/vendor/modernizr-2.8.3.min.js"></script>
  </body>
</html>
