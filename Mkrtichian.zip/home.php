<?php
/**
 * Homepage Template
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package mgd-base
 */

get_header(); ?>

<div class="main">


<?php
  global $query_string;
  query_posts( $query_string . '&cat=45&posts_per_page=1' );
  while ( have_posts() ):
    the_post();
    get_template_part( 'content', 'event-lede' );
  endwhile;
  wp_reset_query();
?>


<?php
  global $query_string;
  query_posts( $query_string . '&cat=45&posts_per_page=5&offset=1' );
  if ( have_posts() ):
?>
  <section class="events">
    <h1 class="events heading">Events</h1>
    <ul class="events items ui">
  <?php
  while ( have_posts() ):
    the_post();
    get_template_part( 'content', 'event-list' );
  endwhile;
  ?>
    </ul><!-- /.events items ui -->

    <div class="footer">
      <a href="?cat=45" class="more button">
        See More
        <span>Graphic Design Events</span>
      </a>
    </div>
  </section>
<?php
  endif;
  wp_reset_query();
?>




  <section class="gallery">
    <h1 class="heading">Current Work</h1><!-- /.heading -->


    <ul class="slides">
      <li class="slide" id="slide-1"><a href="http://lorempixel.com/1000/1000/abstract/1" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/1" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 1</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-1.slide -->


      <li class="slide" id="slide-2"><a href="http://lorempixel.com/1000/1000/abstract/2" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/2" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 2</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-2.slide -->


      <li class="slide" id="slide-3"><a href="http://lorempixel.com/1000/1000/abstract/3" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/3" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 3</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-3.slide -->


      <li class="slide" id="slide-4"><a href="http://lorempixel.com/1000/1000/abstract/4" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/4" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 4</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-4.slide -->


      <li class="slide" id="slide-5"><a href="http://lorempixel.com/1000/1000/abstract/5" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/5" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 5</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-5.slide -->


      <li class="slide" id="slide-6"><a href="http://lorempixel.com/1000/1000/abstract/6" data-rel="gallery" class="link lightbox">
          <img src="http://lorempixel.com/500/500/abstract/6" alt="" class="src">
          <div class="caption">
            <p class="title">Title of Piece 6</p><!-- /.title -->
            <h2 class="name">Name of Artist</h2><!-- /.name -->
          </div><!-- /.caption -->
        </a></li><!-- /#slide-6.slide -->
    </ul><!-- /.slides -->


    <div class="footer">
      <a href="#" class="more button">
        See More
        <span>Graphic Design Work</span>
      </a>
    </div>
  </section><!-- /.gallery -->


<?php
global $post;
$spotifyArgs = array(
  'numberposts' => 1,
  'category' => 18,
  'orderby' => 'rand',
  'meta_query' => array(
    array(
      'key' => 'spotify_url',
      'compare' => 'EXISTS'
    )
  )
);
$spotifyPosts = get_posts( $spotifyArgs );
if ( $spotifyPosts ):
?>
  <section class="spotify">
<?php
  foreach ( $spotifyPosts as $post ):
    setup_postdata( $post );

    get_template_part( 'content', 'spotify-embed' );
  endforeach;
  wp_reset_postdata();
?>
  </section>
<?php
endif;
?>

</div><!-- /.main -->

<?php get_footer(); ?>
