<?php
if ( get_field( 'playlist_creator' ) ):
  $byline = get_field( 'playlist_creator' );
endif;
?>

<div <?php post_class( 'item playlist' ); ?>>
  <div class="header">
    <h1 class="heading">
      <a href="<?php echo esc_url( get_permalink() ) ?>" class="permalink">
        <?php the_title(); ?>
      </a>
    </h1><!-- /.heading -->
    <div class="byline"><em class="type playlist">Playlist by:
      <?php echo $byline; ?>
    </em></div>
  </div><!-- /.header -->
  <div class="copy">
    <iframe src="https://embed.spotify.com/?uri=<?php echo esc_url( get_field( 'spotify_url' ) ) ?>" width="300" height="380" frameborder="0" allowtransparency="true"></iframe>
  </div>
</div><!-- /.item playlist -->
