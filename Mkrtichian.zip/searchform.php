<form class="form searchform" id="searchform" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
  <div class="field">
    <label for="masthead-search"><?php _x( 'Search for:', 'label' ); ?></label>
    <input id="masthead-search" type="text" name="s" placeholder="Search the Site" value="<?php echo get_search_query(); ?>"><?php echo get_search_query(); ?></div>
  <div class="action">
    <button class="control" type="submit"><?php echo esc_attr_x( 'Search', 'submit button' ); ?></button>
  </div>
</form>
