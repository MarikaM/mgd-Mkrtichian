<?php
// Get and format Event Dates;
// TODO: move eventDate to functions.php
if ( get_field( 'event_start_date' ) ):
  $eventDate = '<p class="date">' . get_field( 'event_start_date' );
  if ( get_field( 'event_end_date' ) ):
    $eventDate .= ' – ' . get_field( 'event_end_date' );
  endif;
  $eventDate .= '</p>';
endif;
?>


<li <?php post_class( 'event item teaser' ); ?> id="event-<?php the_ID(); ?>">

      <?php
        $default_attr = array(
          'src'   => $src,
          'class' => "attachment-$size src",
          'alt'   => trim( strip_tags( $wp_postmeta->_wp_attachment_image_alt ) ),
        );
        if ( has_post_thumbnail() ):
      ?>
      <div class="attach">
        <a href="<?php echo esc_url( get_permalink() ) ?>" class="permalink">
        <?php the_post_thumbnail( $default_attr ); ?>
        </a>
      </div>
      <?php
        else:
      ?>
        <img src="http://lorempixel.com/600/600/animals/5" alt="" class="src">
      <?php
        endif;
      ?>
  <div class="body">
    <div class="header">
      <h2 class="heading">
      <a href="<?php echo esc_url( get_permalink() ) ?>" class="permalink">
      <?php the_title() ?>
      </a>
      </h2><!-- /.heading -->
      <div class="meta">
        <?php echo ent2ncr( $eventDate ); ?>
        <p class="location">
        <?php if ( get_field( 'location' ) ): ?>
          <?php the_field( 'location' ) ?>
        <?php endif; ?>
        </p>
      </div><!-- /.meta -->
    </div><!-- /.header -->
    <div class="copy">
      <?php the_excerpt(); ?>
    </div><!-- /.copy -->
  </div><!-- /.body -->
</li><!-- /#event-5.event item teaser -->
